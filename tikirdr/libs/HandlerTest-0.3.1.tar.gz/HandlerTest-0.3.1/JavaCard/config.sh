# Applet dependent data
APPLET_SRC=$(pwd)/src/org/debian/alioth/pcsclite/readertest/*.java
PACKAGE_AID="0xA0:00:00:00:0x18:0xFF"
APPLET_AID=$PACKAGE_AID:01
VERSION=1.0
APPLET=org.debian.alioth.pcsclite.readertest

OUTPUT_DIR=./out

