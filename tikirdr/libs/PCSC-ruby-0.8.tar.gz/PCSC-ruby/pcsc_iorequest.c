/*
    $Id: pcsc_iorequest.c,v 1.7 2004/02/22 02:33:52 toni Exp $
    Copyright (c) 2001 - 2004 Toni Andjelkovic <toni@soth.at>.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.
    3. The name of the author may not be used to endorse or promote products
       derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
    IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
    OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
    IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
    NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
    THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <pcsc_ruby.h>

void Init_PCSC_IORequest(void)
{
    cPCSC_IORequest = rb_define_class_under(mPCSC, "IORequest", rb_cObject);
    rb_define_singleton_method(cPCSC_IORequest, "new", PCSC_IORequest_new, -1);
    rb_define_method(cPCSC_IORequest, "initialize", PCSC_IORequest_init, 0);
    rb_define_method(cPCSC_IORequest, "Protocol", PCSC_IORequest_Protocol_get, 0);
    rb_define_method(cPCSC_IORequest, "Protocol=", PCSC_IORequest_Protocol_set, -1);
    rb_define_method(cPCSC_IORequest, "Length", PCSC_IORequest_Length_get, 0);
    rb_define_method(cPCSC_IORequest, "Length=", PCSC_IORequest_Length_set, -1);
}

VALUE PCSC_IORequest_new(int argc, VALUE *argv, VALUE self)
{
    SCARD_IO_REQUEST *req;

    self = Data_Make_Struct(cPCSC_IORequest, SCARD_IO_REQUEST, NULL, PCSC_IORequest_free, req);
    rb_obj_call_init(self, argc, argv);
    return self;
}

VALUE PCSC_IORequest_init(VALUE self)
{
    SCARD_IO_REQUEST *req;

    Data_Get_Struct(self, SCARD_IO_REQUEST, req);
    return self;
}

VALUE PCSC_IORequest_Protocol_get(VALUE self)
{
    SCARD_IO_REQUEST *req;

    Data_Get_Struct(self, SCARD_IO_REQUEST, req);
    return UINT2NUM(req->dwProtocol);
}

VALUE PCSC_IORequest_Protocol_set(int argc, VALUE *argv, VALUE self)
{
    SCARD_IO_REQUEST *req;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARD_IO_REQUEST, req);
    req->dwProtocol = NUM2ULONG(argv[0]);
    return UINT2NUM(req->dwProtocol);
}

VALUE PCSC_IORequest_Length_get(VALUE self)
{
    SCARD_IO_REQUEST *req;

    Data_Get_Struct(self, SCARD_IO_REQUEST, req);
    return UINT2NUM(req->cbPciLength);
}

VALUE PCSC_IORequest_Length_set(int argc, VALUE *argv, VALUE self)
{
    SCARD_IO_REQUEST *req;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARD_IO_REQUEST, req);
    req->cbPciLength = NUM2ULONG(argv[0]);
    return UINT2NUM(req->cbPciLength);
}

void PCSC_IORequest_free(SCARD_IO_REQUEST *req)
{
    if (req)
        xfree(req);
}
