/*
    $Id: pcsc_context.c,v 1.9 2004/02/22 02:33:52 toni Exp $
    Copyright (c) 2001 - 2004 Toni Andjelkovic <toni@soth.at>.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.
    3. The name of the author may not be used to endorse or promote products
       derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
    IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
    OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
    IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
    NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
    THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <pcsc_ruby.h>

void Init_PCSC_Context(void)
{
    cPCSC_Context = rb_define_class_under(mPCSC, "Context", rb_cObject);
    rb_define_singleton_method(cPCSC_Context, "new", PCSC_Context_new, -1);
    rb_define_method(cPCSC_Context, "initialize", PCSC_Context_init, -1);
    rb_define_method(cPCSC_Context, "ReleaseContext", PCSC_Context_ReleaseContext, 0);
    rb_define_method(cPCSC_Context, "Cancel", PCSC_Context_Cancel, 0);
    rb_define_method(cPCSC_Context, "Unload", PCSC_Context_Unload, 0);
    rb_define_method(cPCSC_Context, "SetTimeout", PCSC_Context_SetTimeout, -1);
    rb_define_method(cPCSC_Context, "ListReaderGroups", PCSC_Context_ListReaderGroups, 0);
    rb_define_method(cPCSC_Context, "ListReaders", PCSC_Context_ListReaders, 0);
    rb_define_method(cPCSC_Context, "GetStatusChange", PCSC_Context_GetStatusChange, -1);
}

VALUE PCSC_Context_new(int argc, VALUE *argv, VALUE self)
{
    SCARDCONTEXT *ctx;

    self = Data_Make_Struct(cPCSC_Context, SCARDCONTEXT, NULL, PCSC_Context_free, ctx);
    rb_obj_call_init(self, argc, argv);
    return self;
}

VALUE PCSC_Context_init(int argc, VALUE *argv, VALUE self)
{
    SCARDCONTEXT *ctx;
    long rv;
    unsigned long scope;

    if (argc > 3 || argc < 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1-3, got %d)", argc);
    scope = argv[0];
    if ((TYPE(scope) != T_FIXNUM) && (TYPE(scope) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARDCONTEXT, ctx);
    rv = SCardEstablishContext(NUM2ULONG(scope), NULL, NULL, ctx);
    if (rv != SCARD_S_SUCCESS)
        rb_raise(rb_eRuntimeError, "SCardEstablishContext: %s", pcsc_stringify_error(rv));
    return self;
}

VALUE PCSC_Context_ListReaders(VALUE self)
{
    SCARDCONTEXT *ctx;
    long rv;
    unsigned long pcchReaders;
    char *mszGroups = NULL;
    char *mszReaders;
    VALUE ary = rb_ary_new();
    char *current;
    unsigned long len;

    Data_Get_Struct(self, SCARDCONTEXT, ctx);
    /* how many bytes to allocate */
    rv = SCardListReaders(*ctx, NULL, NULL, &pcchReaders);
    mszReaders = (char *) ALLOC_N(char, pcchReaders);
    /* real */
    rv = SCardListReaders(*ctx, mszGroups, mszReaders, &pcchReaders);
    if (rv != SCARD_S_SUCCESS)
        rb_raise(rb_eRuntimeError, "SCardListReaders: %s", pcsc_stringify_error(rv));
    current = mszReaders;
    while ((len = strlen(current)) > 0) {
        rb_ary_push(ary, rb_tainted_str_new(current, len));
        current += (len + 1);
    }
    xfree(mszReaders);
    return ary;
}

VALUE PCSC_Context_ListReaderGroups(VALUE self)
{
    SCARDCONTEXT *ctx;
    long rv;
    unsigned long pcchReaders;
    char *mszGroups;

    Data_Get_Struct(self, SCARDCONTEXT, ctx);

    /* how many bytes to allocate */
    rv = SCardListReaderGroups(*ctx, NULL, &pcchReaders);
    mszGroups = (char *) ALLOC_N(char, pcchReaders);
    /* real */
    rv = SCardListReaderGroups(*ctx, mszGroups, &pcchReaders);
    if (rv != SCARD_S_SUCCESS)
        rb_raise(rb_eRuntimeError, "SCardListReaderGroups: %s", pcsc_stringify_error(rv));
    return rb_tainted_str_new2(mszGroups);
}

VALUE PCSC_Context_Cancel(VALUE self)
{
    SCARDCONTEXT *ctx;
    long rv;

    Data_Get_Struct(self, SCARDCONTEXT, ctx);
    rv = SCardCancel(*ctx);
    if (rv != SCARD_S_SUCCESS)
        rb_raise(rb_eRuntimeError, "SCardCancel: %s", pcsc_stringify_error(rv));
    return self;
}

VALUE PCSC_Context_Unload(VALUE self)
{
    SCARDCONTEXT *ctx;
                                                                                                                              
    Data_Get_Struct(self, SCARDCONTEXT, ctx);
    SCardUnload();
    return self;
}

VALUE PCSC_Context_SetTimeout(int argc, VALUE *argv, VALUE self)
{
    SCARDCONTEXT *ctx;
    long rv;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARDCONTEXT, ctx);
    rv = SCardSetTimeout(*ctx, NUM2ULONG(argv[0]));
    if (rv != SCARD_S_SUCCESS)
        rb_raise(rb_eRuntimeError, "SCardSetTimeout: %s", pcsc_stringify_error(rv));
    return self;
}

VALUE PCSC_Context_ReleaseContext(VALUE self)
{
    SCARDCONTEXT *ctx;
    long rv;

    Data_Get_Struct(self, SCARDCONTEXT, ctx);
    rv = SCardReleaseContext(*ctx);
    if (rv != SCARD_S_SUCCESS)
        rb_raise(rb_eRuntimeError, "SCardReleaseContext: %s", pcsc_stringify_error(rv));
    return self;
}

VALUE PCSC_Context_GetStatusChange(int argc, VALUE *argv, VALUE self)
{
    SCARDCONTEXT *ctx;
    SCARD_READERSTATE **rgReaderStates;
    VALUE ary, iterator;
    long i, rv;

    if (argc != 2)
        rb_raise(rb_eArgError, "wrong number of arguments (need 2, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Check_Type((ary = argv[1]), T_ARRAY);
    Data_Get_Struct(self, SCARDCONTEXT, ctx);
    rgReaderStates = ALLOC_N(SCARD_READERSTATE *, RARRAY(ary)->len);
    for (i = 0; i < RARRAY(ary)->len; i++) {
        iterator = rb_ary_entry(ary, i);
        Check_Type(iterator, T_DATA);
        Data_Get_Struct(iterator, SCARD_READERSTATE, rgReaderStates[i]);
    }
    rv = SCardGetStatusChange(*ctx, NUM2ULONG(argv[0]), *rgReaderStates, RARRAY(ary)->len);
    if (rv != SCARD_S_SUCCESS)
        rb_raise(rb_eRuntimeError, "SCardGetStatusChange: %s", pcsc_stringify_error(rv));
    xfree(rgReaderStates);
    return self;
}

void PCSC_Context_free(SCARDCONTEXT *ctx)
{
    if (ctx)
        xfree(ctx);
}
