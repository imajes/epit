/*
    $Id: pcsc_misc.c,v 1.8 2004/02/22 02:33:52 toni Exp $
    Copyright (c) 2001 - 2004 Toni Andjelkovic <toni@soth.at>.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.
    3. The name of the author may not be used to endorse or promote products
       derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
    IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
    OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
    IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
    NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
    THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "pcsc_ruby.h"

VALUE hexify(int argc, VALUE *argv)
{
    int i;
    unsigned char *p, *q; /* iterators, sort of */
    unsigned char *new;
    VALUE str, ret;
    long num_of_chars_to_allocate;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    str = argv[0];
    Check_Type(str, T_STRING);

    /* for each char alloc 2 chars of hex storage */
    num_of_chars_to_allocate = RSTRING(str)->len * 2 + 1;
    /* add room for spaces */
    num_of_chars_to_allocate += (long) RSTRING(str)->len;
    /* alloc temp buffer */
    new = ALLOC_N(unsigned char, num_of_chars_to_allocate);

    p = (unsigned char *) RSTRING(str)->ptr;
    q = new;

    for (i = 0; i < RSTRING(str)->len; ++i) {
        sprintf(q, "%02X", *(p + i));
        q += 2;
        /* add a space, but not after the last element */
        if ((i + 1) >= RSTRING(str)->len)
            ;
        else {
            sprintf(q, " ");
            ++q;
        }
    }

    ret = rb_tainted_str_new2(new);
    xfree(new);
    return ret;
}
