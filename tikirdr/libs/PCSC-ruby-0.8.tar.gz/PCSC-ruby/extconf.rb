# $Id: extconf.rb,v 1.6 2003/07/27 22:54:59 toni Exp $
require "mkmf"

dir_config("pcsclite", with_config("pcsclite-dir"))
have_library("pcsclite")
create_makefile("PCSC")
