/*
    $Id: pcsc_ruby.h,v 1.11 2004/02/22 02:33:52 toni Exp $
    Copyright (c) 2001 - 2004 Toni Andjelkovic <toni@soth.at>.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.
    3. The name of the author may not be used to endorse or promote products
       derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
    IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
    OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
    IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
    NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
    THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <string.h>
#include <sys/types.h>
#include <ruby.h>
#include <winscard.h>

#define MODULE_NAME                 "PCSC"
#define MODULE_VERSION              "0.8"
#define MODULE_BUFSIZE              4096

VALUE mPCSC;                                    /* PCSC Module */
VALUE cPCSC_Context;                            /* PCSC::Context */
VALUE cPCSC_Handle;                             /* PCSC::Handle */
VALUE cPCSC_IORequest;                          /* PCSC::IORequest */
VALUE cPCSC_ReaderState;                        /* PCSC::ReaderState */

/* helper function */
VALUE hexify(int argc, VALUE *argv);

void Init_PCSC_Constants(void);
void Init_PCSC(void);

void Init_PCSC_Context(void);
VALUE PCSC_Context_new(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Context_init(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Context_EstablishContext(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Context_ListReaders(VALUE self);
VALUE PCSC_Context_SetTimeout(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Context_Cancel(VALUE self);
VALUE PCSC_Context_Unload(VALUE self);
VALUE PCSC_Context_ReleaseContext(VALUE self);
VALUE PCSC_Context_GetStatusChange(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Context_ListReaderGroups(VALUE self);
void PCSC_Context_free(SCARDCONTEXT *ptr);

void Init_PCSC_Handle(void);
VALUE PCSC_Handle_new(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Handle_init(VALUE self);
VALUE PCSC_Handle_Connect(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Handle_Disconnect(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Handle_Reconnect(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Handle_BeginTransaction(VALUE self);
VALUE PCSC_Handle_EndTransaction(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Handle_Control(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Handle_CancelTransaction(VALUE self);
VALUE PCSC_Handle_SetTimeout(int argc, VALUE *argv, VALUE self);
VALUE PCSC_Handle_Status(VALUE self);
VALUE PCSC_Handle_Transmit(int argc, VALUE *argv, VALUE self);
void PCSC_Handle_free(SCARDHANDLE *ptr);

void Init_PCSC_IORequest(void);
VALUE PCSC_IORequest_new(int argc, VALUE *argv, VALUE self);
VALUE PCSC_IORequest_init(VALUE self);
VALUE PCSC_IORequest_Protocol_get(VALUE self);
VALUE PCSC_IORequest_Protocol_set(int argc, VALUE *argv, VALUE self);
VALUE PCSC_IORequest_Length_get(VALUE self);
VALUE PCSC_IORequest_Length_set(int argc, VALUE *argv, VALUE self);
void PCSC_IORequest_free(SCARD_IO_REQUEST *req);

void Init_PCSC_ReaderState(void);
VALUE PCSC_ReaderState_new(int argc, VALUE *argv, VALUE self);
VALUE PCSC_ReaderState_init(VALUE self);
VALUE PCSC_ReaderState_Reader_get(VALUE self);
VALUE PCSC_ReaderState_Reader_set(int argc, VALUE *argv, VALUE self);
VALUE PCSC_ReaderState_UserData_get(VALUE self);
VALUE PCSC_ReaderState_UserData_set(int argc, VALUE *argv, VALUE self);
VALUE PCSC_ReaderState_CurrentState_get(VALUE self);
VALUE PCSC_ReaderState_CurrentState_set(int argc, VALUE *argv, VALUE self);
VALUE PCSC_ReaderState_EventState_get(VALUE self);
VALUE PCSC_ReaderState_EventState_set(int argc, VALUE *argv, VALUE self);
VALUE PCSC_ReaderState_cbAtr_get(VALUE self);
VALUE PCSC_ReaderState_cbAtr_set(int argc, VALUE *argv, VALUE self);
VALUE PCSC_ReaderState_rgbAtr_get(VALUE self);
VALUE PCSC_ReaderState_rgbAtr_set(int argc, VALUE *argv, VALUE self);
void PCSC_ReaderState_free(SCARD_READERSTATE *req);
