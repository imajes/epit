/*
    $Id: pcsc_readerstate.c,v 1.6 2004/02/22 02:33:52 toni Exp $
    Copyright (c) 2001 - 2004 Toni Andjelkovic <toni@soth.at>.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.
    3. The name of the author may not be used to endorse or promote products
       derived from this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
    IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
    OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
    IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
    NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
    THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <pcsc_ruby.h>

void Init_PCSC_ReaderState(void)
{
    cPCSC_ReaderState = rb_define_class_under(mPCSC, "ReaderState", rb_cObject);
    rb_define_singleton_method(cPCSC_ReaderState, "new", PCSC_ReaderState_new, -1);
    rb_define_method(cPCSC_ReaderState, "initialize", PCSC_ReaderState_init, 0);
    rb_define_method(cPCSC_ReaderState, "Reader", PCSC_ReaderState_Reader_get, 0);
    rb_define_method(cPCSC_ReaderState, "Reader=", PCSC_ReaderState_Reader_set, -1);
    rb_define_method(cPCSC_ReaderState, "UserData", PCSC_ReaderState_UserData_get, 0);
    rb_define_method(cPCSC_ReaderState, "UserData=", PCSC_ReaderState_UserData_set, -1);
    rb_define_method(cPCSC_ReaderState, "CurrentState", PCSC_ReaderState_CurrentState_get, 0);
    rb_define_method(cPCSC_ReaderState, "CurrentState=", PCSC_ReaderState_CurrentState_set, -1);
    rb_define_method(cPCSC_ReaderState, "EventState", PCSC_ReaderState_EventState_get, 0);
    rb_define_method(cPCSC_ReaderState, "EventState=", PCSC_ReaderState_EventState_set, -1);
    rb_define_method(cPCSC_ReaderState, "cbAtr", PCSC_ReaderState_cbAtr_get, 0);
    rb_define_method(cPCSC_ReaderState, "cbAtr=", PCSC_ReaderState_cbAtr_set, -1);
    rb_define_method(cPCSC_ReaderState, "rgbAtr", PCSC_ReaderState_rgbAtr_get, 0);
    rb_define_method(cPCSC_ReaderState, "rgbAtr=", PCSC_ReaderState_rgbAtr_set, -1);
}

VALUE PCSC_ReaderState_new(int argc, VALUE *argv, VALUE self)
{
    SCARD_READERSTATE *rstate;

    self = Data_Make_Struct(cPCSC_ReaderState, SCARD_READERSTATE, NULL, PCSC_ReaderState_free, rstate);
    rb_obj_call_init(self, argc, argv);
    return self;
}

VALUE PCSC_ReaderState_init(VALUE self)
{
    SCARD_READERSTATE *rstate;

    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    return self;
}

VALUE PCSC_ReaderState_Reader_get(VALUE self)
{
    SCARD_READERSTATE *rstate;

    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    return rb_tainted_str_new2(rstate->szReader);
}

VALUE PCSC_ReaderState_Reader_set(int argc, VALUE *argv, VALUE self)
{
    SCARD_READERSTATE *rstate;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    Check_Type(argv[0], T_STRING);
    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    rstate->szReader = STR2CSTR(argv[0]);
    return rb_tainted_str_new2(rstate->szReader);
}

VALUE PCSC_ReaderState_UserData_get(VALUE self)
{
    SCARD_READERSTATE *rstate;

    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    return rb_tainted_str_new2((char *) rstate->pvUserData);
}

VALUE PCSC_ReaderState_UserData_set(int argc, VALUE *argv, VALUE self)
{
    SCARD_READERSTATE *rstate;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    rstate->pvUserData = STR2CSTR(argv[0]);
    return rb_tainted_str_new2(rstate->pvUserData);
}

VALUE PCSC_ReaderState_CurrentState_get(VALUE self)
{
    SCARD_READERSTATE *rstate;

    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    return UINT2NUM(rstate->dwCurrentState);
}

VALUE PCSC_ReaderState_CurrentState_set(int argc, VALUE *argv, VALUE self)
{
    SCARD_READERSTATE *rstate;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    rstate->dwCurrentState = NUM2ULONG(argv[0]);
    return UINT2NUM(rstate->dwCurrentState);
}

VALUE PCSC_ReaderState_EventState_get(VALUE self)
{
    SCARD_READERSTATE *rstate;

    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    return UINT2NUM(rstate->dwEventState);
}

VALUE PCSC_ReaderState_EventState_set(int argc, VALUE *argv, VALUE self)
{
    SCARD_READERSTATE *rstate;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    rstate->dwEventState = NUM2ULONG(argv[0]);
    return UINT2NUM(rstate->dwEventState);
}

VALUE PCSC_ReaderState_cbAtr_get(VALUE self)
{
    SCARD_READERSTATE *rstate;

    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    return UINT2NUM(rstate->cbAtr);
}

VALUE PCSC_ReaderState_cbAtr_set(int argc, VALUE *argv, VALUE self)
{
    SCARD_READERSTATE *rstate;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    rstate->cbAtr = NUM2ULONG(argv[0]);
    return UINT2NUM(rstate->cbAtr);
}

VALUE PCSC_ReaderState_rgbAtr_get(VALUE self)
{
    SCARD_READERSTATE *rstate;

    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    return rb_tainted_str_new(rstate->rgbAtr, MAX_ATR_SIZE);
}

VALUE PCSC_ReaderState_rgbAtr_set(int argc, VALUE *argv, VALUE self)
{
    SCARD_READERSTATE *rstate;

    if (argc != 1)
        rb_raise(rb_eArgError, "wrong number of arguments (need 1, got %d)", argc);
    if ((TYPE(argv[0]) != T_FIXNUM) && (TYPE(argv[0]) != T_BIGNUM))
        rb_raise(rb_eTypeError, "wrong type of argument");
    Data_Get_Struct(self, SCARD_READERSTATE, rstate);
    MEMCPY(rstate->rgbAtr, STR2CSTR(argv[0]), char, MAX_ATR_SIZE);
    return rb_tainted_str_new(rstate->rgbAtr, MAX_ATR_SIZE);
}

void PCSC_ReaderState_free(SCARD_READERSTATE *rstate)
{
    if (rstate)
        xfree(rstate);
}
